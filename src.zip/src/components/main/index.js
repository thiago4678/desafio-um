import React from "react";
import { View} from "react-native";
import Form from "../Form";
export default function Main(){
    return(
        <View>
            <Form/>
        </View>
    )
}